import React from 'react';
import { Platform, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';

// Importação das telas
import WelcomeScreen from './screens/WelcomeScreen';
import HomeScreen from './screens/HomeScreen';
import FavoritosScreen from './screens/FavoritosScreen';
import ProdutoScreen from './screens/ProdutoScreen';
import CarrinhoScreen from './screens/CarrinhoScreen';
import ContaScreen from './screens/ContaScreen';
import PromocaoScreen from './screens/PromocaoScreen';
import MaisVendidoScreen from './screens/MaisVendidoScreen';
import NoticiaScreen from './screens/NoticiaScreen';

// Bottom Tabs
const Tab = createBottomTabNavigator();

function renderTabIcon(routeName: string, focused: boolean) {
  const iconColor = focused ? '#fbeedb' : '#4B2E2E';
  const backgroundColor = focused ? '#763520' : 'transparent';

  let iconElement;

  switch (routeName) {
    case 'Início':
      iconElement = <Ionicons name="home" size={26} color={iconColor} />;
      break;
    case 'Favoritos':
      iconElement = <Ionicons name="heart" size={26} color={iconColor} />; // ícone trocado para coração
      break;
    case 'Produto':
      iconElement = <Ionicons name="bag-handle" size={26} color={iconColor} />;
      break;
    case 'Carrinho':
      iconElement = <Ionicons name="cart" size={26} color={iconColor} />;
      break;
    case 'Conta':
      iconElement = <Ionicons name="person" size={26} color={iconColor} />;
      break;
    default:
      iconElement = null;
  }

  return (
    <View
      style={{
        backgroundColor,
        paddingHorizontal: 18,
        paddingVertical: 10,
        borderRadius: 30,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: focused ? '#000' : 'transparent',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: focused ? 0.25 : 0,
        shadowRadius: 8,
        elevation: focused ? 8 : 0,
        minWidth: 60,
        minHeight: 50,
      }}
    >
      {iconElement}
    </View>
  );
}

function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: {
          backgroundColor: '#FFFFFF',
          borderTopLeftRadius: 25,
          borderTopRightRadius: 25,
          height: Platform.OS === 'ios' ? 90 : 70,
          paddingBottom: Platform.OS === 'ios' ? 20 : 10,
          paddingTop: 10,
          position: 'absolute',
          left: 0,
          right: 0,
          bottom: 0,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.06,
          shadowRadius: 6,
          elevation: 12,
        },
        tabBarIcon: ({ focused }) => renderTabIcon(route.name, focused),
      })}
    >
      <Tab.Screen name="Início" component={HomeScreen} />
      <Tab.Screen name="Favoritos" component={FavoritosScreen} />
      <Tab.Screen name="Produto" component={ProdutoScreen} />
      <Tab.Screen name="Carrinho" component={CarrinhoScreen} />
      <Tab.Screen name="Conta" component={ContaScreen} />
    </Tab.Navigator>
  );
}

// Stack Navigator
const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Welcome" component={WelcomeScreen} />
        <Stack.Screen name="Home" component={Tabs} />

        {/* Telas extras */}
        <Stack.Screen
          name="Noticia"
          component={NoticiaScreen}
          options={{ title: 'Notícias' }}
        />
        <Stack.Screen
          name="Promocao"
          component={PromocaoScreen}
          options={{ title: 'Promoções' }}
        />
        <Stack.Screen
          name="MaisVendidos"
          component={MaisVendidoScreen}
          options={{ title: 'Mais Vendidos' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
