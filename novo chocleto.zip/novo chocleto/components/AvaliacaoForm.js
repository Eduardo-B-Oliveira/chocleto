import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Animated,
  StyleSheet,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

export default function AvaliacaoForm({ onClose }) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [scaleAnim] = useState(new Animated.Value(1));

  const handleStarPress = (index) => {
    setRating(index);
    Animated.sequence([
      Animated.timing(scaleAnim, { toValue: 1.3, duration: 100, useNativeDriver: true }),
      Animated.timing(scaleAnim, { toValue: 1, duration: 100, useNativeDriver: true }),
    ]).start();
  };

  const handleSubmit = () => {
    alert(`Avaliação enviada: ${rating} estrelas\nComentário: ${comment}`);
    setRating(0);
    setComment('');
    onClose(); // fecha o modal após envio
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={onClose} style={styles.closeButton}>
        <Text style={styles.closeText}>✕</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Avalie este produto</Text>

      <View style={styles.starsContainer}>
        {[1, 2, 3, 4, 5].map((i) => (
          <TouchableOpacity key={i} onPress={() => handleStarPress(i)}>
            <Animated.View style={{ transform: [{ scale: i === rating ? scaleAnim : 1 }] }}>
              <FontAwesome
                name={i <= rating ? 'star' : 'star-o'}
                size={32}
                color="#ff9e0b"
                style={styles.star}
              />
            </Animated.View>
          </TouchableOpacity>
        ))}
      </View>

      <TextInput
        placeholder="Deixe um comentário..."
        value={comment}
        onChangeText={setComment}
        style={styles.input}
        multiline
      />

      <TouchableOpacity onPress={handleSubmit} style={styles.button}>
        <Text style={styles.buttonText}>Enviar Avaliação</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 15,
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#fff3e0',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  starsContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginBottom: 10,
  },
  star: {
    marginHorizontal: 5,
    textShadowColor: '#ffc107',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 6,
    padding: 10,
    height: 80,
    textAlignVertical: 'top',
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#ff9e0b',
    paddingVertical: 10,
    borderRadius: 6,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  closeButton: {
    alignSelf: 'flex-end',
    padding: 5,
  },
  closeText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ff9e0b',
  },
});
