import React from 'react';
import { Text, View, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const newsData = [
  { id: '1', titleb: 'Ver Notícias', title: '', description: '' },
  { id: '2', titleb: '', title: 'Promoção', description: '' },
  { id: '3', titleb: '', title: 'Mais Vendidos', description: '' },
];

const getBackgroundColor = (id) => {
  switch (id) {
    case '1': return '#7a4a3b';
    case '2': return '#b39b73';
    case '3': return '#e6dbcc';
    default: return '#FF8C00';
  }
};

const NewsItem = ({ item }) => {
  const navigation = useNavigation();

  const handlePress = () => {
    if (item.id === '1') navigation.navigate('Noticia');
    else if (item.id === '2') navigation.navigate('Promocao');
    else if (item.id === '3') navigation.navigate('MaisVendidos');
  };

  return (
    <TouchableOpacity onPress={handlePress} activeOpacity={0.8}>
      <View style={[styles.newsItem, { backgroundColor: getBackgroundColor(item.id) }]}>
        {item.titleb ? <Text style={styles.titleb}>{item.titleb}</Text> : null}
        {item.title ? <Text style={styles.title}>{item.title}</Text> : null}
        {item.description ? <Text style={styles.description}>{item.description}</Text> : null}
      </View>
    </TouchableOpacity>
  );
};

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.promoBox}>
        <View style={styles.quadrado}>
          <Text style={styles.promoTitle}>𝐂𝐡𝐨𝐜𝐥𝐞𝐭𝐨</Text>
          <Text style={styles.promoDesc}>Doces que encantam o paladar e adoçam os melhores momentos da vida!</Text>
        </View>
      </View>

      <FlatList
        data={newsData}
        renderItem={({ item }) => <NewsItem item={item} />}
        keyExtractor={item => item.id}
        contentContainerStyle={{ paddingBottom: 16 }}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff8f0',
    padding: 20,
  },
  promoBox: {
    backgroundColor: '#7a4a3b',
    borderRadius: 22,
    paddingVertical: 25,
    paddingHorizontal: 15,
    marginBottom: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 5,
  },
  quadrado: {
    backgroundColor: '#fbeedb',
    borderRadius: 25,
    alignItems: 'center',
    paddingVertical: 25,
    paddingHorizontal: 20,
    width: '100%',
  },
  promoTitle: {
    fontSize: 38,
    fontWeight: '900',
    color: '#4B2E2E',
    marginBottom: 12,
  },
  promoDesc: {
    fontSize: 20,
    color: '#4B2E2E',
    textAlign: 'center',
    lineHeight: 28,
  },
  newsItem: {
    marginVertical: 8,
    padding: 20,
    borderRadius: 40,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2a2a2a',
    marginBottom: 6,
    textAlign: 'center',
  },
  titleb: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 6,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    color: '#fff',
    lineHeight: 22,
    textAlign: 'center',
  },
});
