import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  FlatList,
  TextInput,
  StyleSheet,
  Dimensions,
  SafeAreaView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');
const cardWidth = (width - 60) / 2; // Ajuste dos cards

export default function PesquisaScreen() {
  const [searchText, setSearchText] = useState('');

  const doces = [
    { id: '1', nome: 'Chocolate com castanha (210g)', imagem: require('../assets/11.png') },
    { id: '2', nome: 'Tabletes com frutas (120g)', imagem: require('../assets/10.png') },
    { id: '3', nome: 'Chocolate com castanhas (510g)', imagem: require('../assets/9.png') },
    { id: '4', nome: 'Bombom com jujuba (908g)', imagem: require('../assets/8.png') },
    { id: '5', nome: 'Caixa de bombons sortidos (500g)', imagem: require('../assets/6.png') },
    { id: '6', nome: 'Trufas variadas (300g)', imagem: require('../assets/2.png') },
  ];

  const docesFiltrados = doces.filter((doce) =>
    doce.nome.toLowerCase().includes(searchText.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <View style={styles.cardWrapper}>
      <View style={styles.card}>
        <Image source={item.imagem} style={styles.cardImage} />
        <Text style={styles.cardName}>{item.nome}</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Busque o doce desejado</Text>

      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#888" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Digite o nome do doce..."
          placeholderTextColor="#aaa"
          value={searchText}
          onChangeText={setSearchText}
          clearButtonMode="while-editing"
          underlineColorAndroid="transparent"
        />
      </View>

      <FlatList
        data={docesFiltrados}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        numColumns={2}
        columnWrapperStyle={styles.row}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 60, paddingTop: 10 }}
        ListEmptyComponent={
          <Text style={styles.emptyText}>Nenhum doce encontrado.</Text>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FDF9F7',
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#3E2723',
    marginBottom: 15,
    textAlign: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 19,
    paddingHorizontal: 15,
    paddingVertical: Platform.OS === 'ios' ? 12 : 8,
    alignItems: 'center',
    marginBottom: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 5,
    margin:25,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    padding: 0,
    margin: 0,
    borderWidth: 0, // Garante que não apareça borda preta
    outlineStyle: 'none', // útil para Web/Expo Web
  },
  row: {
    justifyContent: 'center',
    marginTop: 20,
    marginBottom: 10,
  },
  cardWrapper: {
    marginHorizontal: 10,
    marginBottom: 20,
  },
  card: {
    width: cardWidth,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 4,
  },
  cardImage: {
    width: '100%',
    height: cardWidth - 20,
    borderRadius: 10,
    marginBottom: 10,
    resizeMode: 'cover',
  },
  cardName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#3E2723',
    textAlign: 'center',
  },
  emptyText: {
    marginTop: 40,
    fontSize: 16,
    color: '#8D6E63',
    textAlign: 'center',
  },
});
