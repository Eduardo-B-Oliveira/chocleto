import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');
const cardWidth = (width - 60) / 2; // 60 = paddingHorizontal + gap

export default function CarrinhoScreen() {
  const [carrinho, setCarrinho] = useState([
    {
      id: '1',
      nome: 'Chocolate com castanha (210g)',
      preco: 20.0,
      quantidade: 1,
      imagem: require('../assets/2.png'),
    },
    {
      id: '2',
      nome: 'Tabletes com frutas (120g)',
      preco: 23.1,
      quantidade: 2,
      imagem: require('../assets/6.png'),
    },
    {
      id: '3',
      nome: 'Chocolate com castanhas (510g)',
      preco: 30.09,
      quantidade: 1,
      imagem: require('../assets/4.png'),
    },
    {
      id: '4',
      nome: 'Bombom com jujuba (908g)',
      preco: 49.1,
      quantidade: 2,
      imagem: require('../assets/5.png'),
    },
  ]);

  const alterarQuantidade = (id, tipo) => {
    setCarrinho((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              quantidade:
                tipo === 'mais'
                  ? item.quantidade + 1
                  : item.quantidade > 1
                  ? item.quantidade - 1
                  : 1,
            }
          : item
      )
    );
  };

  const removerItem = (id) => {
    setCarrinho((prev) => prev.filter((item) => item.id !== id));
  };

  const calcularTotal = () => {
    return carrinho
      .reduce((total, item) => total + item.preco * item.quantidade, 0)
      .toFixed(2);
  };

  const renderItem = ({ item }) => (
    <View style={styles.cardWrapper}>
      <View style={styles.card}>
        <Image source={item.imagem} style={styles.cardImage} />
        <Text style={styles.cardName}>{item.nome}</Text>
        <Text style={styles.cardPrice}>R$ {item.preco.toFixed(2)}</Text>
        <View style={styles.qtdContainer}>
          <TouchableOpacity onPress={() => alterarQuantidade(item.id, 'menos')}>
            <Ionicons name="remove-circle-outline" size={24} color="#d32f2f" />
          </TouchableOpacity>
          <Text style={styles.qtdTexto}>{item.quantidade}</Text>
          <TouchableOpacity onPress={() => alterarQuantidade(item.id, 'mais')}>
            <Ionicons name="add-circle-outline" size={24} color="#388e3c" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => removerItem(item.id)} style={{ marginLeft: 10 }}>
            <Ionicons name="trash-outline" size={24} color="#757575" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Seu Carrinho</Text>

      <FlatList
        data={carrinho}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        numColumns={2}
        columnWrapperStyle={styles.row}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 40 }}
        ListFooterComponent={
          <View style={styles.footer}>
            <Text style={styles.totalText}>Total: R$ {calcularTotal()}</Text>
            <TouchableOpacity style={styles.button}>
              <Text style={styles.buttonText}>Finalizar Compra</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FDF9F7',
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#3E2723',
    marginBottom: 20,
    textAlign: 'center',
  },
  row: {
    justifyContent: 'center',
    marginBottom: 20,
  },
  cardWrapper: {
    marginHorizontal: 10,
  },
  card: {
    width: cardWidth,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    padding: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 4,
  },
  cardImage: {
    width: '100%',
    height: cardWidth - 20,
    borderRadius: 10,
    marginBottom: 10,
    resizeMode: 'cover',
  },
  cardName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#3E2723',
    textAlign: 'center',
    marginBottom: 4,
  },
  cardPrice: {
    color: '#5D4037',
    marginBottom: 4,
  },
  qtdContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
  },
  qtdTexto: {
    marginHorizontal: 10,
    fontSize: 16,
    fontWeight: 'bold',
  },
  footer: {
    marginTop: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 6,
    alignItems: 'center',
    marginBottom: 30,
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4E342E',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#6D4C41',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    width: '100%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
