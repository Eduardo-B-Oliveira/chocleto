import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';

export default function NoticiaScreen() {
  const navigation = useNavigation();

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={20} color="#fff" />
        <Text style={styles.backText}>Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.text}>𝗡𝗼𝘁𝗶́𝗰𝗶𝗮𝘀 𝗱𝗲 𝗛𝗼𝗷𝗲</Text>

      <View style={styles.tudo}>
        <Text style={styles.duck}>𝐁𝐨𝐥𝐨 𝐝𝐞 𝐂𝐡𝐮𝐫𝐫𝐨𝐬 𝐀𝐠𝐨𝐫𝐚 𝐅𝐚𝐳 𝐏𝐚𝐫𝐭𝐞 𝐝𝐨 𝐍𝐨𝐬𝐬𝐨 𝐂𝐚𝐫𝐝𝐚́𝐩𝐢𝐨!</Text>
        <Text style={styles.context}>Sim, você leu certo! A combinação perfeita entre o doce 
        de leite cremoso e a massa macia com toque de canela agora está disponível por aqui...</Text>
      </View>

      <View style={styles.tudo1}>
        <Text style={styles.duck1}>𝐏𝐞𝐬𝐪𝐮𝐢𝐬𝐚 𝐑𝐞𝐯𝐞𝐥𝐚: 𝐂𝐨𝐦𝐞𝐫 𝐂𝐡𝐨𝐜𝐨𝐥𝐚𝐭𝐞 𝐌𝐞𝐥𝐡𝐨𝐫𝐚 𝐨 𝐇𝐮𝐦𝐨𝐫!</Text>
        <Text style={styles.context1}>Se você precisava de uma desculpa para comer chocolate, aqui está...</Text>
      </View>

      <View style={styles.tudo2}>
        <Text style={styles.duck2}>🎉 𝐏𝐫𝐨𝐦𝐨𝐜̧𝐚̃𝐨 𝐝𝐨 𝐌𝐞̂𝐬: 𝐅𝐫𝐞𝐭𝐞 𝐆𝐫𝐚́𝐭𝐢𝐬</Text>
        <Text style={styles.context2}>Para celebrar o mês do chocolate, a Chocleto oferece frete grátis...</Text>
      </View>

      <View style={styles.tudo3}>
        <Text style={styles.duck3}>𝐍𝐨𝐯𝐢𝐝𝐚𝐝𝐞: 𝐂𝐡𝐨𝐜𝐥𝐞𝐭𝐨 𝐂𝐫𝐨𝐜𝐚𝐧𝐭𝐞 𝐝𝐞 𝐀𝐦𝐞𝐧𝐝𝐨𝐢𝐦!</Text>
        <Text style={styles.context3}>Amantes de um bom crocante, preparem-se...</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { 
    paddingVertical: 20,
    alignItems: 'center',
    paddingBottom: 80, 
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#522b1b',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    marginBottom: 10,
    marginLeft: 10,
    alignSelf: 'flex-start',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 4,
  },
  backText: {
    color: '#fff',
    fontWeight: 'bold',
    marginLeft: 8,
    fontSize: 16,
  },
  tudo:{
    backgroundColor: '#e8ddcd',
    borderRadius: 10,
    width: 360,
    justifyContent: 'center',
    marginBottom: 22,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 5,
  },
  tudo1:{
    backgroundColor: '#9a7959',
    borderRadius: 10,
    width: 360,
    justifyContent: 'center',
    marginBottom: 22,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 5,
  },
  tudo2:{
    backgroundColor: '#522b1b',
    borderRadius: 10,
    width: 360,
    justifyContent: 'center',
    marginBottom: 22,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 5,
  },
  tudo3:{
    backgroundColor: '#75422d',
    borderRadius: 10,
    width: 360,
    justifyContent: 'center',
    marginBottom: 22,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 5,
  },
  text: { 
    fontSize: 30,
    display: 'flex',
    justifyContent: 'center',
    paddingBottom: 22,
    color: '#000',
    margin: 20,
  },
  duck: {
    fontSize: 25,
    justifyContent:'center',
    left:10,
    margin: 20,
  },
  duck1: {
    fontSize: 25,
    justifyContent:'center',
    left:10,
    margin: 20,
    color:'#fff'
  },
  duck2: {
    fontSize: 25,
    justifyContent:'center',
    left:10,
    margin: 20,
    color:'#fff'
  },
  duck3: {
    fontSize: 25,
    justifyContent:'center',
    left:10,
    margin: 20,
    color:'#fff'
  },
  context:{
    fontSize: 20,
    justifyContent:'center',
    margin: 18,
    left: 11,
  },
  context1:{
    fontSize: 20,
    justifyContent:'center',
    margin: 18,
    left: 11,
    color:'#fff'
  },
  context2:{
    fontSize: 20,
    justifyContent:'center',
    margin: 18,
    left: 11,
    color:'#fff'
  },
  context3:{
    fontSize: 20,
    justifyContent:'center',
    margin: 18,
    left: 11,
    color:'#fff'
  },
});
