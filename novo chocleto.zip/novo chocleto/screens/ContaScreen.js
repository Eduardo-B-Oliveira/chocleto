import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  ScrollView,
  Alert,
  StatusBar,
  Platform,
} from 'react-native';
import { Feather, MaterialIcons, Ionicons } from '@expo/vector-icons';

export default function ContaScreen() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [themeDark, setThemeDark] = useState(false);

  const [user, setUser] = useState({
    name: 'João Silva',
    email: 'joao@example.com',
    photo: 'https://i.pravatar.cc/150?img=12',
  });

  const [editName, setEditName] = useState(user.name);
  const [editEmail, setEditEmail] = useState(user.email);
  const [editPhoto, setEditPhoto] = useState(user.photo);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  function handleLogin() {
    if (!loginEmail || !loginPassword) {
      Alert.alert('Erro', 'Digite email e senha!');
      return;
    }
    setIsLoggedIn(true);
    setLoginEmail('');
    setLoginPassword('');
  }

  function changePhoto() {
    const randomId = Math.floor(Math.random() * 70) + 1;
    const newPhoto = `https://i.pravatar.cc/150?img=${randomId}`;
    setEditPhoto(newPhoto);
  }

  function saveProfile() {
    setUser({
      name: editName,
      email: editEmail,
      photo: editPhoto,
    });
    setEditMode(false);
  }

  function logout() {
    setIsLoggedIn(false);
    setEditMode(false);
  }

  const dynamicStyles = themeDark ? darkStyles : styles;

  if (!isLoggedIn) {
    return (
      <View style={dynamicStyles.container}>
        <Text style={dynamicStyles.title}>Chocleto Login</Text>

        <View style={dynamicStyles.inputContainer}>
          <Feather name="mail" size={20} color="#8B4513" style={dynamicStyles.inputIcon} />
          <TextInput
            placeholder="Email"
            placeholderTextColor="#bfa089"
            value={loginEmail}
            onChangeText={setLoginEmail}
            style={dynamicStyles.input}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
          />
        </View>

        <View style={dynamicStyles.inputContainer}>
          <Feather name="lock" size={20} color="#8B4513" style={dynamicStyles.inputIcon} />
          <TextInput
            placeholder="Senha"
            placeholderTextColor="#bfa089"
            value={loginPassword}
            onChangeText={setLoginPassword}
            secureTextEntry
            style={dynamicStyles.input}
          />
        </View>

        <TouchableOpacity onPress={handleLogin} style={dynamicStyles.button}>
          <Text style={dynamicStyles.buttonText}>Entrar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={dynamicStyles.scroll} contentContainerStyle={dynamicStyles.container}>
      <Text style={dynamicStyles.title}>Meu Perfil</Text>

      <TouchableOpacity onPress={changePhoto} activeOpacity={0.7}>
        <Image source={{ uri: editMode ? editPhoto : user.photo }} style={dynamicStyles.avatar} />
        {editMode && <Text style={dynamicStyles.editPhoto}>Toque para mudar a foto</Text>}
      </TouchableOpacity>

      {editMode ? (
        <>
          <View style={dynamicStyles.editInputContainer}>
            <Feather name="user" size={20} color="#8B4513" style={dynamicStyles.editIcon} />
            <TextInput
              style={dynamicStyles.editInput}
              value={editName}
              onChangeText={setEditName}
              placeholder="Nome"
              placeholderTextColor="#bfa089"
              autoCapitalize="words"
              autoCorrect={false}
            />
          </View>

          <View style={dynamicStyles.editInputContainer}>
            <Feather name="mail" size={20} color="#8B4513" style={dynamicStyles.editIcon} />
            <TextInput
              style={dynamicStyles.editInput}
              value={editEmail}
              onChangeText={setEditEmail}
              placeholder="Email"
              placeholderTextColor="#bfa089"
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>

          <View style={dynamicStyles.row}>
            <TouchableOpacity onPress={() => setEditMode(false)} style={dynamicStyles.buttonCancel}>
              <Text style={dynamicStyles.buttonText}>Cancelar</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={saveProfile} style={dynamicStyles.button}>
              <Text style={dynamicStyles.buttonText}>Salvar</Text>
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <>
          <Text style={dynamicStyles.infoText}>Nome: {user.name}</Text>
          <Text style={dynamicStyles.infoText}>Email: {user.email}</Text>
          <TouchableOpacity onPress={() => setEditMode(true)} style={dynamicStyles.button}>
            <Text style={dynamicStyles.buttonText}>Editar Perfil</Text>
          </TouchableOpacity>
        </>
      )}

      <Text style={dynamicStyles.sectionTitle}>Configurações</Text>

      <TouchableOpacity
        style={dynamicStyles.option}
        onPress={() => setThemeDark(!themeDark)}
      >
        <Ionicons
          name={themeDark ? 'moon' : 'sunny'}
          size={20}
          color="#8B4513"
          style={{ marginRight: 10 }}
        />
        <Text style={dynamicStyles.optionText}>
          Tema: {themeDark ? 'Escuro' : 'Claro'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity style={dynamicStyles.option}>
        <MaterialIcons name="security" size={20} color="#8B4513" style={{ marginRight: 10 }} />
        <Text style={dynamicStyles.optionText}>Segurança e Senha</Text>
      </TouchableOpacity>

      <TouchableOpacity style={dynamicStyles.option}>
        <Ionicons name="notifications" size={20} color="#8B4513" style={{ marginRight: 10 }} />
        <Text style={dynamicStyles.optionText}>Notificações</Text>
      </TouchableOpacity>

      <Text style={dynamicStyles.sectionTitle}>Ajuda</Text>

      <TouchableOpacity style={dynamicStyles.option}>
        <MaterialIcons name="question-answer" size={20} color="#8B4513" style={{ marginRight: 10 }} />
        <Text style={dynamicStyles.optionText}>Perguntas Frequentes</Text>
      </TouchableOpacity>

      <TouchableOpacity style={dynamicStyles.option}>
        <MaterialIcons name="email" size={20} color="#8B4513" style={{ marginRight: 10 }} />
        <Text style={dynamicStyles.optionText}>Fale Conosco</Text>
      </TouchableOpacity>

      <TouchableOpacity style={dynamicStyles.option}>
        <MaterialIcons name="policy" size={20} color="#8B4513" style={{ marginRight: 10 }} />
        <Text style={dynamicStyles.optionText}>Política de Privacidade</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={logout} style={dynamicStyles.buttonLogout}>
        <Text style={dynamicStyles.buttonText}>Sair da Conta</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const baseStyles = {
  scroll: { backgroundColor: '#F8F3EF' },
  container: {
    flexGrow: 1,
    backgroundColor: '#F8F3EF',
    alignItems: 'center',
    padding: 24,
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight + 10 : 50,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#5C4033',
    marginBottom: 22,
  },

  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff6e7',
    borderColor: '#C49E6C',
    borderWidth: 1.8,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 18,
    shadowColor: '#cbb994',
    shadowOpacity: 0.4,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 5,
    elevation: 5,
    outlineStyle: 'none',
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    fontSize: 18,
    color: '#5C4033',
    fontWeight: '600',
    outlineStyle: 'none',
  },

  avatar: {
    width: 130,
    height: 130,
    borderRadius: 65,
    borderWidth: 3,
    borderColor: '#D2B48C',
    marginBottom: 12,
  },
  editPhoto: {
    color: '#8B4513',
    marginBottom: 12,
    fontSize: 14,
    textAlign: 'center',
  },

  editInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff6e7',
    borderColor: '#C49E6C',
    borderWidth: 1.5,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 14,
    shadowColor: '#cbb994',
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 5,
    elevation: 4,
    outlineStyle: 'none',
  },
  editIcon: {
    marginRight: 12,
  },
  editInput: {
    flex: 1,
    fontSize: 17,
    color: '#5C4033',
    fontWeight: '500',
    outlineStyle: 'none',
  },

  infoText: {
    fontSize: 17,
    color: '#3E2723',
    marginVertical: 6,
  },
  button: {
    backgroundColor: '#8B4513',
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 30,
    marginVertical: 14,
    shadowColor: '#6e4b2a',
    shadowOpacity: 0.8,
    shadowOffset: { width: 0, height: 6 },
    shadowRadius: 10,
    elevation: 6,
  },
  buttonCancel: {
    backgroundColor: '#aaa',
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 30,
    marginVertical: 14,
  },
  buttonLogout: {
    backgroundColor: '#A52A2A',
    paddingVertical: 16,
    paddingHorizontal: 36,
    borderRadius: 30,
    marginTop: 30,
    marginBottom: 60,
    alignSelf: 'center',
    shadowColor: '#7a2b2b',
    shadowOpacity: 0.9,
    shadowOffset: { width: 0, height: 6 },
    shadowRadius: 10,
    elevation: 8,
    
  },
  buttonText: {
    color: '#FFF8F0',
    fontWeight: 'bold',
    fontSize: 18,
    textAlign: 'center',
  },
  sectionTitle: {
    alignSelf: 'flex-start',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 30,
    marginBottom: 16,
    color: '#5C4033',
  },
  option: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 14,
    backgroundColor: '#fff',
    marginBottom: 12,
    shadowColor: '#d4b38b',
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 7,
    elevation: 5,
  },
  optionText: {
    fontSize: 17,
    color: '#3E2723',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    gap: 16,
  },
};

const styles = StyleSheet.create(baseStyles);

const darkStyles = StyleSheet.create({
  ...baseStyles,
  scroll: { backgroundColor: '#2b1b14' },
  container: {
    ...baseStyles.container,
    backgroundColor: '#2b1b14',
  },
  title: { ...baseStyles.title, color: '#F8F3EF' },

  inputContainer: {
    ...baseStyles.inputContainer,
    backgroundColor: '#3c2a20',
    borderColor: '#a78a7f',
  },
  input: {
    ...baseStyles.input,
    color: '#F8F3EF',
    outlineStyle: 'none',
  },

  avatar: {
    ...baseStyles.avatar,
    borderColor: '#a78a7f',
  },
  editPhoto: {
    color: '#f5e0d4',
    marginBottom: 12,
    fontSize: 14,
    textAlign: 'center',
  },

  editInputContainer: {
    ...baseStyles.editInputContainer,
    backgroundColor: '#3c2a20',
    borderColor: '#a78a7f',
  },
  editInput: {
    ...baseStyles.editInput,
    color: '#F8F3EF',
    outlineStyle: 'none',
  },

  infoText: {
    ...baseStyles.infoText,
    color: '#f5e0d4',
  },
  button: {
    ...baseStyles.button,
    backgroundColor: '#6b4a2b',
    shadowColor: '#3f2d1b',
  },
  buttonCancel: {
    ...baseStyles.buttonCancel,
    backgroundColor: '#555',
  },
  buttonLogout: {
    ...baseStyles.buttonLogout,
    backgroundColor: '#b33e3e',
    shadowColor: '#7a2b2b',
  },
  buttonText: {
    ...baseStyles.buttonText,
    color: '#F8F3EF',
  },
  sectionTitle: {
    ...baseStyles.sectionTitle,
    color: '#f1e0d6',
  },
  option: {
    ...baseStyles.option,
    backgroundColor: '#3c2a20',
    shadowColor: '#23160d',
  },
  optionText: {
    ...baseStyles.optionText,
    color: '#f5e0d4',
  },
});

