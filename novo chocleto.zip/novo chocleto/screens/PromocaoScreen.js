import React from 'react';
import { Text, View, FlatList, Image, TextInput, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { FontAwesome, Ionicons } from '@expo/vector-icons'; 
import { useNavigation } from '@react-navigation/native';

const produtos = [
  {
    id: '1',
    nome: 'Doce Especial',
    precoOriginal: 'R$9,00',
    precoDesconto: 'R$3,99',
    imagem: require('../assets/3.png'),
  },
  {
    id: '2',
    nome: 'Doce Premium',
    precoOriginal: 'R$15,20',
    precoDesconto: 'R$7,99',
    imagem: require('../assets/5.png'),
  },
  {
    id: '3',
    nome: 'Doce Gourmet',
    precoOriginal: 'R$20,10',
    precoDesconto: 'R$15,00',
    imagem: require('../assets/2.png'),
  },
];

export default function PromocaoScreen() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      {/* Botão Voltar */}
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={20} color="#fff" />
        <Text style={styles.backText}>Voltar</Text>
      </TouchableOpacity>

      <View style={styles.promoBox}>
        <View style={styles.quadrado}>
          <Text style={styles.promoTitle}>𝐏𝐑𝐎𝐌𝐎𝐂̧𝐀̃𝐎</Text>
          <Text style={styles.promoDesc}>
            Promoção que faz sua compra valer mais!
          </Text>
          <Text style={styles.promoOff}>OFF 50%</Text>
        </View>
      </View>

      <View style={styles.searchContainer}>
        <FontAwesome name="search" size={20} color="#888" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Buscar produtos..."
          placeholderTextColor="#888"
        />
      </View>

      <FlatList
        data={produtos}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Image source={item.imagem} style={styles.itemImage} />
            <View>
              <Text style={styles.itemName}>{item.nome}</Text>
              <View style={styles.prices}>
                <Text style={styles.oldPrice}>{item.precoOriginal}</Text>
                <Text style={styles.newPrice}>{item.precoDesconto}</Text>
              </View>
            </View>
          </View>
        )}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 40 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF9F2',
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
  },

  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#522b1b',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    marginBottom: 15,
    alignSelf: 'flex-start',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 4,
  },
  backText: {
    color: '#fff',
    fontWeight: 'bold',
    marginLeft: 8,
    fontSize: 16,
  },

  promoBox: {
    marginBottom: 20,
  },

  quadrado: {
    backgroundColor: '#FEE2C5',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 5,
  },

  promoTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4B2E2E',
    marginBottom: 8,
  },

  promoDesc: {
    fontSize: 14,
    color: '#4B2E2E',
    textAlign: 'center',
    marginBottom: 10,
  },

  promoOff: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#C7361E',
  },

  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 19,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 6,
    elevation: 4,
  },

  searchIcon: {
    marginRight: 8,
  },

  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#333',
    outlineStyle: 'none',
  },

  item: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 14,
    marginBottom: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 5,
    elevation: 3,
  },

  itemImage: {
    width: 90,
    height: 90,
    borderRadius: 18,
    marginRight: 14,
    resizeMode: 'cover',
    borderWidth: 1,
    borderColor: '#E3C9B6',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 3,
  },

  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4B2E2E',
    marginBottom: 4,
  },

  prices: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  oldPrice: {
    fontSize: 14,
    textDecorationLine: 'line-through',
    color: '#888',
    marginRight: 8,
  },

  newPrice: {
    fontSize: 16,
    color: '#C7361E',
    fontWeight: 'bold',
  },
});
