import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Modal,
} from 'react-native';
import { FontAwesome, Ionicons } from '@expo/vector-icons';
import AvaliacaoForm from '../components/AvaliacaoForm';
import { useNavigation } from '@react-navigation/native';

export default function MaisVendidosScreen() {
  const [modalVisible, setModalVisible] = useState(false);
  const navigation = useNavigation();

  return (
    <View style={styles.screenContainer}>
      {/* Botão Voltar */}
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={20} color="#fff" />
        <Text style={styles.backText}>Voltar</Text>
      </TouchableOpacity>

      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.banner}>
          <Text style={styles.title}>OS QUERIDINHOS DA CHOCLETO CHEGARAM!</Text>
          <Text style={styles.subtitle}>
            Vem conferir o Top Chocleto e se apaixonar também! 💛
          </Text>
        </View>

        <Text style={styles.sectionTitle}>Top melhores categorias</Text>

        {/* Card Chocleto */}
        <View style={styles.card}>
          <Image source={require('../assets/tits.png')} style={styles.icon} />
          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>chocleto</Text>
            <Text style={styles.cardPercentage}>100%</Text>

            <View style={styles.stars}>
              {Array.from({ length: 5 }).map((_, index) => (
                <FontAwesome
                  key={index}
                  name="star-o"
                  size={24}
                  color="#ff9e0b"
                  style={styles.starIcon}
                />
              ))}
            </View>

            <TouchableOpacity onPress={() => setModalVisible(true)}>
              <Text style={styles.link}>Vá correndo avaliar também ➝</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Card Nutrimekt */}
        <View style={styles.card}>
          <Image source={require('../assets/tits.png')} style={styles.icon} />
          <View style={styles.cardContent}>
            <Text style={styles.cardTitle}>Nutrimelt</Text>
            <Text style={styles.cardPercentage}>100%</Text>

            <View style={styles.stars}>
              {Array.from({ length: 5 }).map((_, index) => (
                <FontAwesome
                  key={index}
                  name="star-o"
                  size={24}
                  color="#ff9e0b"
                  style={styles.starIcon}
                />
              ))}
            </View>

            <TouchableOpacity onPress={() => setModalVisible(true)}>
              <Text style={styles.link}>Vá correndo avaliar também ➝</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {/* Modal Avaliação */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.overlay}>
          <View style={styles.modalContainer}>
            <AvaliacaoForm onClose={() => setModalVisible(false)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: '#FFF8F0',
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#3B1F14',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    margin: 16,
    alignSelf: 'flex-start',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 4,
  },
  backText: {
    color: '#fff',
    fontWeight: 'bold',
    marginLeft: 8,
    fontSize: 16,
  },
  container: {
    padding: 16,
  },
  banner: {
    backgroundColor: '#5D2C1D',
    padding: 24,
    borderRadius: 12,
    marginBottom: 24,
  },
  title: {
    color: '#FFE6D0',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  subtitle: {
    color: '#FFE6D0',
    fontSize: 14,
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#4B2A20',
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#3B1F14',
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  icon: {
    width: 99,
    height: 99,
    marginRight: 16,
  },
  cardContent: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    textTransform: 'capitalize',
    color: '#FFF5C2',
    textShadowColor: '#FFDD55',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 8,
    marginBottom: 4,
  },
  cardPercentage: {
    color: '#FFFFFF',
    fontSize: 12,
    marginBottom: 6,
  },
  stars: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
    marginBottom: 5,
  },
  starIcon: {
    marginHorizontal: 2,
  },
  link: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    width: '90%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
});
