import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  FlatList,
  TextInput,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Platform,
  Alert,
} from 'react-native';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');
const cardWidth = (width - 80) / 2;

export default function FavoritosScreen() {
  const [searchText, setSearchText] = useState('');

  const doces = [
    { id: '1', nome: 'Chocolate com castanha (210g)', imagem: require('../assets/11.png') },
    { id: '2', nome: 'Tabletes com frutas (120g)', imagem: require('../assets/10.png') },
    { id: '3', nome: 'Chocolate com castanhas (510g)', imagem: require('../assets/9.png') },
    { id: '4', nome: 'Bombom com jujuba (908g)', imagem: require('../assets/8.png') },
    { id: '5', nome: 'Caixa de bombons sortidos (500g)', imagem: require('../assets/6.png') },
    { id: '6', nome: 'Trufas variadas (300g)', imagem: require('../assets/2.png') },
  ];

  const docesFiltrados = doces.filter((doce) =>
    doce.nome.toLowerCase().includes(searchText.toLowerCase())
  );

  const renderItem = ({ item }) => (
    <View style={styles.cardWrapper}>
      <View style={styles.card}>
        <Image source={item.imagem} style={styles.cardImage} />
        <Text style={styles.cardName} numberOfLines={2}>{item.nome}</Text>
        <TouchableOpacity style={styles.removeButton} activeOpacity={0.7}>
          <MaterialIcons name="delete-outline" size={20} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );

  function handleAdd() {
    Alert.alert('Adicionar', 'Aqui você pode abrir o modal ou tela para adicionar um doce!');
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="heart" size={26} color="#FF6F61" style={styles.icon} />
        <Text style={styles.title}>Favoritos</Text>
      </View>

      <View style={styles.searchContainer}>
        <Ionicons name="search" size={22} color="#999" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Buscar doce favorito..."
          placeholderTextColor="#bbb"
          value={searchText}
          onChangeText={setSearchText}
          underlineColorAndroid="transparent"
          clearButtonMode="while-editing"
        />
      </View>

      <FlatList
        data={docesFiltrados}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        numColumns={2}
        columnWrapperStyle={styles.row}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <Text style={styles.emptyText}>Nenhum doce encontrado.</Text>
        }
      />

      {/* Botão + fixo */}
      <TouchableOpacity style={styles.addButton} onPress={handleAdd} activeOpacity={0.8}>
        <Text style={styles.addButtonText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF9F7',
    paddingHorizontal: 20,
    paddingTop: 40,
    position: 'relative',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  icon: {
    marginRight: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#FF6F61',
    letterSpacing: 1,
  },
  searchContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 25,
    paddingHorizontal: 18,
    paddingVertical: Platform.OS === 'ios' ? 14 : 10,
    alignItems: 'center',
    marginBottom: 25,
    shadowColor: '#FF6F61',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 6,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 17,
    color: '#555',
    padding: 0,
    outlineStyle: 'none',
  },
  row: {
    justifyContent: 'center',
    marginBottom: 25,
  },
  listContent: {
    paddingBottom: 140, // espaço para botão + e menu
    paddingTop: 10,
    alignItems: 'center',
  },
  cardWrapper: {
    width: cardWidth,
    marginHorizontal: 10,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#FF6F61',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.14,
    shadowRadius: 15,
    elevation: 8,
    position: 'relative',
  },
  cardImage: {
    width: '100%',
    height: cardWidth - 30,
    borderRadius: 16,
    marginBottom: 14,
    resizeMode: 'cover',
  },
  cardName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6D4C41',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 14,
  },
  removeButton: {
    position: 'absolute',
    top: 14,
    right: 14,
    backgroundColor: '#FF6F61',
    borderRadius: 18,
    padding: 6,
    shadowColor: '#FF6F61',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
    elevation: 6,
  },
  emptyText: {
    marginTop: 60,
    fontSize: 17,
    color: '#BCAAA4',
    textAlign: 'center',
  },
  addButton: {
    position: 'absolute',
    bottom: 90, // mantém acima do menu
    right: 30,
    backgroundColor: '#FF6F61',
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#FF6F61',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 10,
    zIndex: 9999,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 28,
    lineHeight: 28,
    fontWeight: '900',
    marginBottom: 2,
  },
});
